// Importing Mongoose
const mongoose = require("mongoose");

// Loading environment variables
require("dotenv").config(); 

// Creating Database Connection Function
exports.connect = ()=>{
    mongoose.connect(process.env.DB_URL,{
        useNewUrlParser: true,
        useUnifiedTopology:true,
    }).then(()=>{console.log("DB Connection Successfull")})
    .catch((err)=>{
        console.log(err);
        console.error(err);
        process.exit(1);
    })
}