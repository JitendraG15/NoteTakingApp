// importing Required Schema's and Library
const User = require("../models/SampleUser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// Signup Handler To Register A New User
exports.signup = async (req, res) => {
    try {
      // Destructuring fields from the request body
      const {fullName, email, password, confirmPassword} = req.body;

      // Check if All Details are there or not
      if (!fullName  ||!email ||!password ||!confirmPassword) {
        return res.status(403).send({
          success: false,
          message: "All Fields are required",
        });
      }

      // Check if password and confirm password match or not
      if (password !== confirmPassword) {
        return res.status(400).json({
          success: false,
          message:
            "Password and Confirm Password do not match",
        });
      }
  
      // Check if user already exists or not
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: "User already exists. Please Login To Continue.",
        });
      } 

      // Hashing the password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Creating User Entry in Database
     const user = await User.create({
        fullName:fullName,
        email:email,
        password:hashedPassword
     });

    //  Checking if User Registered or Not
     if(!user){
        return res.status(401).json({
            success:false,
            message:"User Not Created",
            user
        })
     }

    //  Returning Success Response
      return res.status(200).json({
        success: true,
        message: "User registered successfully",
        user
      });
    } catch (error) {
      // Handling Error
      console.error(error);
      return res.status(500).json({
        success: false,
        message: "User cannot be registered. Please try again.",
      });
    }
  };


  // Login Handler
exports.login = async (req, res) => {
    try{
      // Fetching Email & Password
      const {email, password} = req.body;
      console.log("Email->", email, "Password->", password);

      // Check if email or password is missing or not
      if (!email || !password) {
        return res.status(400).json({
          success: false,
          message: `Fill All Required Fields`,
        })
      }
  
      // Find user with Registered email
      const user = await User.findOne({email})

    // Checking User Exists or not  // 
    if (!user) {
      return res.status(404).json({
        success: false,
        message: `User is not Registered with Us. Please SignUp to Continue`,
      });
    }
      console.log("User:", user);
     
  
      // Generate JWT token and Comparing Password
      if (await bcrypt.compare(password, user.password)) {
        const token = jwt.sign(
          { email: user.email, id: user._id },
          process.env.JWT_SECRET,    
          {
            expiresIn: "24h",    
          }
        )
  
        // Creating User Object with some extra Fields in it
        const userResponse = {
          _id: user._id,
          fullName: user.fullName,
          email: user.email,
          token: token,
        };
        
        
        
        // Setting cookie for token and return success response
        const options = {
          expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          httpOnly: true,
        }

        // Returing Cookie as success response
        return res.cookie("token", token, options).status(200).json({
          success: true,
          token,
          user:userResponse,
          message: `User Logged In Successfully`,
        })
      } else {
        return res.status(401).json({
          success: false,
          message: `Password is incorrect`,
        })
      }
  
    }catch(error){
      // Handling Error
      console.error(error);
      return res.status(500).json({
        success:false,
        message:"Unknown Error Occured While User Login"
      })
    }
  }