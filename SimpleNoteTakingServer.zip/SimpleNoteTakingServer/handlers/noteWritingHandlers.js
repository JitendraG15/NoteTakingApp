// Importing Note Schema for further Operations
const Note = require("../models/Note");

// Handler To Create A Note
exports.createNote = async (req, res) => {
  try {
    // destructuring title and content form body of request
    const { title, content } = req.body;

    // Checking whether title & content are empty or not
    if (!title || !content) {
      return res.status(400).json({
        success: false,
        message: "All Fields Are Required",
      });
    }

    // Oobject creation for better readiablity
    const newNote = {
      title: title,
      content: content,
      lastModifiedAt: Date.now(),
    };

    // Creating a New Note
    const note = await Note.create(newNote);

    // Checking if New Note is created or not
    if (!note) {
      return res.status(500).json({
        success: false,
        message: "Unable To Create New Note",
      });
    }

    // Returning Success Response
    return res.status(201).json({
      success: true,
      message: "New Notes Created Successfully",
      note,
    });
  } catch (error) {
    // Handling Error
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Error While Creating Notes",
    });
  }
};

// Handler To Fetch A Particular Note Given Note ID
exports.getNote = async (req, res) => {
  try {
    // Fetching ID To Retrieve Note Information
    const { note_id } = req.query || req.params || req.body;

    // Checking if ID is Fetched or not
    if (!note_id) {
      return res.status(400).json({
        success: false,
        message: "Note ID is Required",
      });
    }

    // Fetching Note From Database which will have title, content, createdAt & lastModifiedAt Fields compulsurly
    const note = await Note.findById(
      { _id: note_id },
      { title: true, content: true, createdAt: true, lastModifiedAt: true }
    );

    //  Checking if Note is there in the database or not
    if (!note) {
      return res.status(401).json({
        success: false,
        message: "No Such Note Found",
      });
    }

    // Returning Success Response containing Note
    return res.status(200).json({
      success: true,
      message: "Note Fetched Successfully",
      note,
    });
  } catch (error) {
    // Handling Error
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Error While Fetching Note",
    });
  }
};

// Handler To Fetch all Notes in General
exports.getNotes = async (req, res) => {
  try {
    // Fetching All Notes From Database
    const notes = await Note.find(
      {},
      { title: true, content: true, createdAt: true, lastModifiedAt: true }
    );


    // Checking If Notes Found or not
    if (!notes) {
      return res.status(404).json({
        success: false,
        message: "No Notes Found",
      });
    }

    // Return Success Response
    return res.status(200).json({
      success: true,
      message: "All Notes Fetched Successfully",
      notes,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Error While Fetching Notes",
    });
  }
};

// Handler To Update a Particular Note Given it's ID
exports.updateNote = async (req, res) => {
  try {
    // Fetching ID by Multiple Options
    const { note_id } = req.query || req.params || req.body;

    // Fetching Updated title and Content
    const {title, content } = req.body;

    // Checking if ID is there or not
    if (!note_id) {
      return res.status(400).json({
        success: false,
        message: "Note ID is required To Proceed",
      });
    }

    // Updating the Note and returning updated Note
    const updatedNote = await Note.findByIdAndUpdate(
      { _id: note_id },
      {
        title: title,
        content: content,
      },
      { new: true }
    );



    // Checking if The returned the updated Note or not
    if (!updatedNote) {
      return res.status(401).json({
        success: false,
        message: "Not A Valid Note",
      });
    }

    // Returning Success Response containing updatedNote
    return res.status(200).json({
      success: true,
      message: "Note Updated Successfully",
      updatedNote,
    });
  } catch (error) {
    // Handling Error
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Error While Updating Note",
    });
  }
};

// Handler To Delete a Particular Note Given it's ID
exports.deleteNote = async (req, res) => {
  try {
    // Fetching Notes ID
    const { note_id } = req.query || req.params || req.body;

    // Checking if ID is there or not
    if (!note_id) {
      return res.status(400).json({
        success: false,
        message: "Note ID is required To Proceed",
      });
    }

    // Deleting The Note having Particular ID
    const deletedNote = await Note.findByIdAndDelete({ _id: note_id });

    // Retuning Success Response
    return res.status(200).json({
      success: true,
      message: "Note Deleted Successfully",
      deletedNote,
    });
  } catch (error) {
    // Handling Errors
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Error While Deleting Note",
    });
  }
};
