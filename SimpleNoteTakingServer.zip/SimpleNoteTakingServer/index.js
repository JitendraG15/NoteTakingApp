// Importing required modules
const express = require("express");
const database = require("./configurations/databaseConnection");
const cookieParser = require("cookie-parser");
const authRoute = require("./routes/authRoutes");
const noteRoute = require("./routes/noteRoute");

// Creating App/Server
const app = express();

// Loading environment Variables
require("dotenv").config();

// Loading Port Number From env File
const port = process.env.PORT || 4000;

// Making Database Connection
database.connect();

// Adding Middleware to parser json document and cookie parser
app.use(express.json());
app.use(cookieParser());

// Defining Middlewares for different routes
app.use("/api/v1", authRoute);
app.use("/api/v1/service", noteRoute);

// Making Server Live
app.listen(port, () => {
  console.log("Server is listening at port number ", port);
});
