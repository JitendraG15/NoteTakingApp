const express = require("express");
const router = express.Router();

// Importing Handlers 
const {signup, login} = require("../handlers/auth");

router.post("/signup",signup ) //Signup Route
router.post("/login", login) //Login Route

// Exporting Router
module.exports = router;