const express = require("express");
const router = express.Router();

// Importing Middleware for user authentication
const {auth} = require("../middlewares/AuthMiddleware");

// Importing Handler dealing with Note
const {createNote,getNote, getNotes, updateNote, deleteNote} = require("../handlers/noteWritingHandlers")


// Defining Different Routes for Different tasks
router.post("/createNote",auth, createNote );
router.get("/fetchNote", auth, getNote);
router.get("/fetchNotes", auth, getNotes);
router.put("/updateNote", auth, updateNote);
router.delete("/deleteNote", auth, deleteNote);

// Exporting router
module.exports = router;