const mongoose = require("mongoose");

// Creating User Schema
const userSchema = new mongoose.Schema({
  fullName:{
    type:String,
    required:true,
  },
  email:{
    type:String,
    required:true
  },
  password:{
    type:String,
    required:true
  }
});



// Exporting User Schema for the use in other Files
module.exports = mongoose.model("User", userSchema);
