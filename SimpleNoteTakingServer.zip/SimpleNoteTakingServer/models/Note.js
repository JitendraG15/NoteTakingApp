const mongoose = require("mongoose");

// Creating Note Schema
const noteSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    minlength: 5, // Minimum length for the title
    maxlength: 100,
  },
  content: {
    type: String,
    required: true,
    minlength: 10,
    maxlength: 5000,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  lastModifiedAt: {
    type: Date,
  },
});

// Middleware to update lastModified before saving
noteSchema.pre("save", function (next) {
  this.lastModified = new Date();
  next();
});

// Exporting Note Schema For the use in other Files
module.exports = mongoose.model("Note", noteSchema);
